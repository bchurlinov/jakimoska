<?php
$name = $_POST['name'];
$email = $_POST['email'];
$subject = $_POST['subject'];
$message = $_POST['message'];
$formcontent=" From: $name Message: $message";
$recipient = "aleksandra@jakimoska.com";
$subject = "Contact Form";
$mailheader = "From: $email \r\n";
mail($recipient, $subject, $formcontent, $mailheader) or die("Error!");
//echo "Thank You!" . " -" . "<a href='form.html' style='text-decoration:none;color:#ff0099;'> Return Home</a>";
?>

<h1 style="text-align:center;">Thank you for submitting your question. We will contact you very soon.</h1>
<a href='/' style="display:block; text-align:center; color:#00BCD4"> Get back to www.terzievski.com </a>